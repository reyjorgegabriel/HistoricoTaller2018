package uy.com.antel;
import java.net.*;
import java.io.*;

public class mainServer {
    public static void main(String[] args){

        try {
            ServerSocket socket = new ServerSocket(1500);
            System.out.println("1");
            Socket socketRecepcion = null;
            socketRecepcion = socket.accept();
            BufferedReader lectura;
            lectura = new BufferedReader(new InputStreamReader(socketRecepcion.getInputStream()));

            while(true) {
                //System.out.println("2");
                //socketRecepcion = socket.accept();
                System.out.println("lectura");
                System.out.println("3");
                //BufferedReader lectura;
                String s;
                //System.out.println("4");
                //lectura = new BufferedReader(new InputStreamReader(socketRecepcion.getInputStream()));

                //System.out.println("5");

                System.out.println(lectura.readLine());

                //escribir algo
            }

        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
