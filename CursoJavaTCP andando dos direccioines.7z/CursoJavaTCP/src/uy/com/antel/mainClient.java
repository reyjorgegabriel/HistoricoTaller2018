package uy.com.antel;
import java.net.*;
import java.io.*;

public class mainClient {
    public static void main(String[] args){

        try {Socket sock = null;
            sock = new Socket("127.0.0.1",1500);

            PrintWriter escritura;
            BufferedReader teclado;
            String linea;
            teclado=new BufferedReader(new InputStreamReader(System.in));
            escritura=new PrintWriter(sock.getOutputStream(),true);


            BufferedReader lectura;
            lectura = new BufferedReader(new InputStreamReader(sock.getInputStream()));



            do {
                linea=teclado.readLine();
                escritura.println(linea);

                //leer respuesta
                String s = lectura.readLine();
                System.out.println(s);

            } while (linea.compareTo("#")!=0);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
