@javax.xml.bind.annotation.XmlSchema(namespace = "http://antel.com.uy/")
package uy.com.antel;
