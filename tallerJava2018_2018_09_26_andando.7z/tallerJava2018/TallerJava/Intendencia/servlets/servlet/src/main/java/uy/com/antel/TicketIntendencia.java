package uy.com.antel;

import java.util.Date;

public class TicketIntendencia {
    private int agencia;
    private String matricula;
    private Date fechaHoraVenta;


}
