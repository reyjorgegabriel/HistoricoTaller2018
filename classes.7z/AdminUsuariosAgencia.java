package uy.com.antel;

public class AdminUsuariosAgencia {

    //es un singleton
    private static AdminUsuariosAgencia ourInstance = new AdminUsuariosAgencia();

    public static AdminUsuariosAgencia getInstance() {
        return ourInstance;
    }

    private AdminUsuariosAgencia() {
    }

    public boolean validarAcceso(Credenciales credenciales){
        //para probar, devuelve siempre verdadero
        return true;
    }






}
